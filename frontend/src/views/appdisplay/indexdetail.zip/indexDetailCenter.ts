import type {
    IndexMarketStatus,
    IndexOverallView,
    IndexRiskLevel,
    IndexValuationStatus,
    MetricStatus,
    MetricTrend
} from './constants'

/**
 * 指数详情页聚合数据。
 *
 */
export interface IndexDetail {
    profile: IndexProfile
    quote?: IndexQuote
    indicator?: IndexIndicatorDaily
    overview: IndexOverview
    metricCards: MetricCard[]
    charts: ChartGroup[]
    performance: IndexPerformanceInterval[]
    constituents?: IndexConstituentInfo
    meta: ResponseMeta
}

/**
 * 指数基础信息。
 *
 * 来源表：type_basic_data.index_basic_data
 */
export interface IndexProfile {
    /** type_basic_data.index_basic_data.full_symbol：指数代码全称，包含交易所后缀 */
    fullSymbol: string

    /** type_basic_data.index_basic_data.name：指数简称 */
    name: string

    /** type_basic_data.index_basic_data.fullname：指数全称 */
    fullname?: string

    /** type_basic_data.index_basic_data.market：市场，例如 MSCI / CSI / SSE / SZSE / SW */
    market?: string

    /** market 的中文展示名，前端根据字典转换得到，不要求物理表存储 */
    marketName?: string

    /** type_basic_data.index_basic_data.publisher：发布方 */
    publisher?: string

    /** type_basic_data.index_basic_data.index_type：指数风格 */
    indexType?: string

    /** type_basic_data.index_basic_data.category：指数类别 */
    category?: string

    /** type_basic_data.index_basic_data.base_date：基期 */
    baseDate?: string

    /** type_basic_data.index_basic_data.base_point：基点 */
    basePoint?: number

    /** type_basic_data.index_basic_data.list_date：发布日期 */
    listDate?: string

    /** type_basic_data.index_basic_data.weight_rule：加权方式 */
    weightRule?: string

    /** type_basic_data.index_basic_data.description：描述 */
    description?: string

    /** type_basic_data.index_basic_data.exp_date：终止日期 */
    expDate?: string

    /** 页面展示标签，由 market / category / indexType / weightRule 组合生成 */
    tags?: string[]
}

/**
 * 指数行情快照。
 *
 * 来源表：type_exchange_data.index_k_daily
 */
export interface IndexQuote {
    /** type_exchange_data.index_k_daily.full_symbol */
    fullSymbol: string

    /** type_exchange_data.index_k_daily.trade_date */
    tradeDate: string

    /** 页面展示用时间；日频数据通常为空或 15:00:00 */
    tradeTime?: string

    /** type_exchange_data.index_k_daily.close：收盘价 */
    close?: number

    /** type_exchange_data.index_k_daily.open：开盘价 */
    open?: number

    /** type_exchange_data.index_k_daily.high：最高价 */
    high?: number

    /** type_exchange_data.index_k_daily.low：最低价 */
    low?: number

    /** type_exchange_data.index_k_daily.pre_close：前一交易日收盘价 */
    preClose?: number

    /** type_exchange_data.index_k_daily.chg_amt：涨跌额 */
    chgAmt?: number

    /** type_exchange_data.index_k_daily.chg_pct：涨跌幅，单位 % */
    chgPct?: number

    /** 振幅，页面层用 high / low / preClose 计算，物理表未直接存储 */
    amplitude?: number

    /** type_exchange_data.index_k_daily.volume：成交量，单位手 */
    volume?: number

    /** type_exchange_data.index_k_daily.turnover：成交额，单位千元 */
    turnover?: number

    /** type_exchange_data.index_indicator_daily.turnover_rate：换手率 */
    turnoverRate?: number

    /** type_exchange_data.index_indicator_daily.turnover_rate_free：自由流通换手率 */
    turnoverRateFree?: number

    marketStatus: IndexMarketStatus
}

/**
 * 指数估值与规模指标。
 *
 * 来源表：type_exchange_data.index_indicator_daily
 */
export interface IndexIndicatorDaily {
    /** type_exchange_data.index_indicator_daily.full_symbol */
    fullSymbol: string

    /** type_exchange_data.index_indicator_daily.trade_date */
    tradeDate: string

    /** type_exchange_data.index_indicator_daily.total_market_value：总市值，单位元 */
    totalMarketValue?: number

    /** type_exchange_data.index_indicator_daily.float_market_value：流通市值，单位元 */
    floatMarketValue?: number

    /** type_exchange_data.index_indicator_daily.total_share：总股本，单位股 */
    totalShare?: number

    /** type_exchange_data.index_indicator_daily.float_share：流通股本，单位股 */
    floatShare?: number

    /** type_exchange_data.index_indicator_daily.free_share：自由流通股本，单位股 */
    freeShare?: number

    /** type_exchange_data.index_indicator_daily.turnover_rate：换手率 */
    turnoverRate?: number

    /** type_exchange_data.index_indicator_daily.turnover_rate_free：自由流通换手率 */
    turnoverRateFree?: number

    /** type_exchange_data.index_indicator_daily.pe：市盈率 */
    pe?: number

    /** type_exchange_data.index_indicator_daily.pe_ttm：市盈率 TTM */
    peTtm?: number

    /** type_exchange_data.index_indicator_daily.pb：市净率 */
    pb?: number

    /** 页面层估值状态，可由 peTtm / pb 分位或业务规则计算 */
    valuationStatus?: IndexValuationStatus

    /** 页面层估值结论，非物理表字段 */
    conclusion?: string
}

/**
 * 成分股信息。
 *
 * 主来源表：
 * - type_basic_data.index_constituent_data
 *
 * 补充表：
 * - type_basic_data.stock_basic_data：补齐名称、行业
 * - type_exchange_data.stock_k_daily：补齐最新收盘价和涨跌幅
 */
export interface IndexConstituentItem {
    /** type_basic_data.index_constituent_data.index_code */
    indexCode: string

    /** type_basic_data.index_constituent_data.stock_code */
    stockCode: string

    /** type_basic_data.index_constituent_data.trade_date */
    tradeDate: string

    /** type_basic_data.index_constituent_data.weight：权重，单位 % */
    weight?: number

    /** type_basic_data.stock_basic_data.name */
    name?: string

    /** type_basic_data.stock_basic_data.industry */
    industry?: string

    /** type_exchange_data.stock_k_daily.close */
    close?: number

    /** type_exchange_data.stock_k_daily.chg_pct */
    chgPct?: number

    /** 对指数涨跌的贡献，页面层可按 weight * chgPct 近似计算 */
    contribution?: number
}

export interface IndexConstituentInfo {
    /** 成分股对应交易日，来自 index_constituent_data.trade_date */
    tradeDate?: string

    /** 成分股总数 */
    totalCount: number

    upCount?: number
    downCount?: number
    flatCount?: number

    /** 前十大权重股 */
    topWeights: IndexConstituentItem[]

    /** 涨幅靠前成分股 */
    topGainers: IndexConstituentItem[]

    /** 跌幅靠前成分股 */
    topLosers: IndexConstituentItem[]

    /** 行业权重汇总，由 stock_basic_data.industry + index_constituent_data.weight 聚合 */
    industryWeights: WeightItem[]

    /** 全量成分股列表，表格可分页展示 */
    records: IndexConstituentItem[]
}

export interface WeightItem {
    name: string
    weight: number
}

export interface IndexOverview {
    overallView: IndexOverallView
    overallViewText: string
    valuationStatus?: IndexValuationStatus
    riskLevel: IndexRiskLevel
    confidence?: number
    summary: string
    reasons: string[]
    risks: string[]
    suggestions: string[]
}

export interface MetricCard {
    key: string
    title: string
    value: string | number
    unit?: string
    displayValue?: string
    trend?: MetricTrend
    status?: MetricStatus
    description?: string
    compareText?: string
    sortOrder?: number
}

export interface IndexPerformanceInterval {
    periodCode: string
    periodName: string
    changePercent?: number
    maxDrawdown?: number
    volatility?: number
    rankingText?: string
}

export interface ChartGroup {
    chartId: string
    title: string
    chartType: 'LINE' | 'CANDLESTICK' | 'BAR' | 'PIE' | 'TABLE'
    period?: 'DAILY' | 'WEEKLY' | 'MONTHLY'
    xAxis?: string[]
    series: ChartSeries[]
    options?: Record<string, unknown>
}

export interface ChartSeries {
    name: string
    data: Array<number | string | null | OHLCData>
    unit?: string
}

export interface OHLCData {
    /** type_exchange_data.index_k_daily.trade_date */
    tradeDate: string

    /** type_exchange_data.index_k_daily.open */
    open: number

    /** type_exchange_data.index_k_daily.high */
    high: number

    /** type_exchange_data.index_k_daily.low */
    low: number

    /** type_exchange_data.index_k_daily.close */
    close: number

    /** type_exchange_data.index_k_daily.volume */
    volume?: number

    /** type_exchange_data.index_k_daily.turnover */
    turnover?: number
}

export interface ResponseMeta {
    dataSource: string
    dataVersion?: string
    generatedAt: string
    cacheExpireAt?: string
    partialData?: boolean
    warnings?: string[]
}
