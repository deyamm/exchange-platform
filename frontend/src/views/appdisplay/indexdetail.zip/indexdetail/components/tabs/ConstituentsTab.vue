<template>
    <div class="constituents-tab">
        <el-empty v-if="!constituents" description="暂无成分股数据" />

        <template v-else>
            <el-row :gutter="12">
                <el-col :xs="24" :sm="12" :lg="6">
                    <el-card shadow="never" class="summary-card">
                        <div class="summary-label">成分股数量</div>
                        <div class="summary-value">{{ constituents.totalCount }}</div>
                        <div class="summary-desc">trade_date：{{ constituents.tradeDate || '-' }}</div>
                    </el-card>
                </el-col>

                <el-col :xs="24" :sm="12" :lg="6">
                    <el-card shadow="never" class="summary-card">
                        <div class="summary-label">上涨数量</div>
                        <div class="summary-value is-up">{{ constituents.upCount || 0 }}</div>
                        <div class="summary-desc">stock_k_daily.chg_pct &gt; 0</div>
                    </el-card>
                </el-col>

                <el-col :xs="24" :sm="12" :lg="6">
                    <el-card shadow="never" class="summary-card">
                        <div class="summary-label">下跌数量</div>
                        <div class="summary-value is-down">{{ constituents.downCount || 0 }}</div>
                        <div class="summary-desc">stock_k_daily.chg_pct &lt; 0</div>
                    </el-card>
                </el-col>

                <el-col :xs="24" :sm="12" :lg="6">
                    <el-card shadow="never" class="summary-card">
                        <div class="summary-label">平盘数量</div>
                        <div class="summary-value">{{ constituents.flatCount || 0 }}</div>
                        <div class="summary-desc">stock_k_daily.chg_pct = 0</div>
                    </el-card>
                </el-col>
            </el-row>

            <el-row :gutter="12" class="chart-row">
                <el-col :xs="24" :lg="12">
                    <el-card shadow="never" class="tab-card">
                        <template #header>
                            <span class="card-title">行业权重分布</span>
                        </template>
                        <IndexEcharts :option="industryWeightOption" height="340px" />
                    </el-card>
                </el-col>

                <el-col :xs="24" :lg="12">
                    <el-card shadow="never" class="tab-card">
                        <template #header>
                            <span class="card-title">成分涨跌分布</span>
                        </template>
                        <IndexEcharts :option="breadthOption" height="340px" />
                    </el-card>
                </el-col>
            </el-row>

            <el-card shadow="never" class="tab-card">
                <template #header>
                    <div class="card-header">
                        <span class="card-title">成分股列表</span>
                        <span class="header-tip">权重来自 index_constituent_data.weight</span>
                    </div>
                </template>

                <el-table :data="constituents.records" border height="420">
                    <el-table-column prop="stockCode" label="代码" min-width="120" align="center" />
                    <el-table-column prop="name" label="名称" min-width="120" />
                    <el-table-column prop="industry" label="行业" min-width="120" />
                    <el-table-column label="权重" width="110" align="right">
                        <template #default="{ row }">{{ formatPercent(row.weight) }}</template>
                    </el-table-column>
                    <el-table-column label="收盘价" width="110" align="right">
                        <template #default="{ row }">{{ formatNumber(row.close, 2) }}</template>
                    </el-table-column>
                    <el-table-column label="涨跌幅" width="110" align="right">
                        <template #default="{ row }">
                            <span :class="signedClass(row.chgPct)">
                                {{ formatPercent(row.chgPct, 2, true) }}
                            </span>
                        </template>
                    </el-table-column>
                    <el-table-column label="贡献" width="110" align="right">
                        <template #default="{ row }">{{ formatPercent(row.contribution, 4, true) }}</template>
                    </el-table-column>
                </el-table>
            </el-card>
        </template>
    </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { IndexConstituentInfo } from '/@/types/indexdetail/indexDetailCenter'
import IndexEcharts from '../charts/IndexEcharts.vue'
import { buildBreadthPieOption, buildPieOption } from '../../utils/indexDetailChartOptions'
import { formatNumber, formatPercent, signedClass } from '../../utils/indexDetailFormat'

const props = defineProps<{
    constituents?: IndexConstituentInfo
}>()

const industryWeightOption = computed(() => {
    return buildPieOption('行业权重分布', props.constituents?.industryWeights || [])
})

const breadthOption = computed(() => {
    return buildBreadthPieOption(props.constituents)
})
</script>

<style scoped>
.constituents-tab {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.summary-card {
    height: 116px;
}

.summary-label {
    color: var(--el-text-color-secondary);
    font-size: 13px;
}

.summary-value {
    margin-top: 10px;
    font-size: 24px;
    font-weight: 700;
    line-height: 1.2;
}

.summary-desc {
    margin-top: 8px;
    color: var(--el-text-color-secondary);
    font-size: 12px;
}

.chart-row {
    row-gap: 12px;
}

.tab-card {
    border-radius: 10px;
}

.card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
}

.card-title {
    font-weight: 600;
    color: #303133;
}

.header-tip {
    color: var(--el-text-color-secondary);
    font-size: 12px;
    font-weight: 400;
}

.is-up {
    color: #f56c6c;
}

.is-down {
    color: #67c23a;
}

.is-flat {
    color: #606266;
}
</style>
