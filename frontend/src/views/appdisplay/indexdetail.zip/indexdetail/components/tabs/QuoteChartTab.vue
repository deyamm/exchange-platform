<template>
    <div class="quote-chart-tab">
        <el-row :gutter="16">
            <el-col :xs="24" :lg="16">
                <div class="chart-list">
                    <el-card v-for="chart in charts" :key="chart.chartId" class="chart-card" shadow="never">
                        <template #header>
                            <div class="chart-header">
                                <span>{{ chart.title }}</span>
                                <div class="chart-actions">
                                    <el-tag size="small" type="info">{{ chart.chartType }}</el-tag>
                                    <el-button
                                        link
                                        type="primary"
                                        @click="activeRawChartId = activeRawChartId === chart.chartId ? '' : chart.chartId"
                                    >
                                        {{ activeRawChartId === chart.chartId ? '隐藏数据' : '查看数据' }}
                                    </el-button>
                                </div>
                            </div>
                        </template>

                        <IndexEcharts
                            :option="buildOption(chart)"
                            :height="chart.chartType === 'CANDLESTICK' ? '430px' : '340px'"
                        />

                        <el-table
                            v-if="activeRawChartId === chart.chartId && chart.chartType === 'CANDLESTICK'"
                            :data="ohlcRows(chart).slice().reverse()"
                            border
                            height="260"
                            class="raw-table"
                        >
                            <el-table-column prop="tradeDate" label="日期" min-width="110" align="center" />
                            <el-table-column prop="open" label="开盘" width="90" align="right" />
                            <el-table-column prop="high" label="最高" width="90" align="right" />
                            <el-table-column prop="low" label="最低" width="90" align="right" />
                            <el-table-column prop="close" label="收盘" width="90" align="right" />
                            <el-table-column label="成交量" min-width="120" align="right">
                                <template #default="{ row }">{{ formatAmount(row.volume) }}</template>
                            </el-table-column>
                            <el-table-column label="成交额" min-width="120" align="right">
                                <template #default="{ row }">{{ formatAmount(row.turnover) }}</template>
                            </el-table-column>
                        </el-table>
                    </el-card>
                </div>
            </el-col>

            <el-col :xs="24" :lg="8">
                <el-card class="quote-summary-card" shadow="never">
                    <template #header>
                        <span class="card-title">区间表现</span>
                    </template>
                    <el-table :data="performance" border>
                        <el-table-column prop="periodName" label="区间" min-width="90" />
                        <el-table-column label="涨跌幅" min-width="90" align="right">
                            <template #default="{ row }">
                                <span :class="signedClass(row.changePercent)">
                                    {{ formatPercent(row.changePercent, 2, true) }}
                                </span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="rankingText" label="排名" min-width="80" />
                    </el-table>
                </el-card>

                <el-card class="quote-summary-card" shadow="never">
                    <template #header>
                        <span class="card-title">行情摘要</span>
                    </template>
                    <el-descriptions :column="1" border size="small">
                        <el-descriptions-item label="最新点位">{{ formatNumber(quote?.close, 2) }}</el-descriptions-item>
                        <el-descriptions-item label="涨跌幅">
                            <span :class="signedClass(quote?.chgPct)">
                                {{ formatPercent(quote?.chgPct, 2, true) }}
                            </span>
                        </el-descriptions-item>
                        <el-descriptions-item label="成交额">{{ formatAmount(quote?.turnover) }}</el-descriptions-item>
                        <el-descriptions-item label="换手率">{{ formatPercent(quote?.turnoverRate) }}</el-descriptions-item>
                    </el-descriptions>
                </el-card>

                <el-card class="quote-summary-card" shadow="never">
                    <template #header>
                        <span class="card-title">字段来源</span>
                    </template>
                    <div class="chart-note">
                        K 线图字段来自 type_exchange_data.index_k_daily：open、high、low、close、volume、turnover、chg_pct。
                    </div>
                </el-card>
            </el-col>
        </el-row>
    </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import type { EChartsOption } from 'echarts'
import type { ChartGroup, IndexPerformanceInterval, IndexQuote } from '/@/types/indexdetail/indexDetailCenter'
import IndexEcharts from '../charts/IndexEcharts.vue'
import { buildBarOption, buildCandlestickOption, buildLineOption, getOhlcRows } from '../../utils/indexDetailChartOptions'
import { formatAmount, formatNumber, formatPercent, signedClass } from '../../utils/indexDetailFormat'

defineProps<{
    quote?: IndexQuote
    charts: ChartGroup[]
    performance: IndexPerformanceInterval[]
}>()

const activeRawChartId = ref('')

function buildOption(chart: ChartGroup): EChartsOption {
    if (chart.chartType === 'CANDLESTICK') return buildCandlestickOption(chart)
    if (chart.chartType === 'BAR') return buildBarOption(chart)
    return buildLineOption(chart, chart.chartId.includes('percent'))
}

function ohlcRows(chart: ChartGroup) {
    return getOhlcRows(chart)
}
</script>

<style scoped>
.quote-chart-tab {
    min-height: 420px;
}

.chart-list {
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.chart-card,
.quote-summary-card {
    border-radius: 10px;
}

.quote-summary-card + .quote-summary-card {
    margin-top: 16px;
}

.chart-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.chart-actions {
    display: flex;
    align-items: center;
    gap: 8px;
}

.card-title {
    font-weight: 600;
    color: #303133;
}

.raw-table {
    margin-top: 12px;
}

.chart-note {
    font-size: 13px;
    line-height: 1.7;
    color: #606266;
}

.is-up {
    color: #f56c6c;
}

.is-down {
    color: #67c23a;
}

.is-flat {
    color: #606266;
}
</style>
