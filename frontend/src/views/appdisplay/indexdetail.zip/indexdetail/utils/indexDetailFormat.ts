import type {
    IndexMarketStatus,
    IndexOverallView,
    IndexRiskLevel,
    IndexValuationStatus,
    MetricStatus
} from '/@/types/indexdetail/constants'

export function formatDateTime(input?: string | null): string {
    if (!input) return '-'
    return String(input).replace('T', ' ')
}

export function formatDate(input?: string | null): string {
    if (!input) return '-'
    return String(input).slice(0, 10)
}

export function formatNumber(value?: number | null, digits = 2): string {
    if (value === undefined || value === null || Number.isNaN(Number(value))) return '-'
    return Number(value).toLocaleString('zh-CN', {
        minimumFractionDigits: digits,
        maximumFractionDigits: digits
    })
}

export function formatPercent(value?: number | null, digits = 2, showSign = false): string {
    if (value === undefined || value === null || Number.isNaN(Number(value))) return '-'
    const sign = showSign && value > 0 ? '+' : ''
    return `${sign}${formatNumber(value, digits)}%`
}

/**
 * 金额 / 数量格式化。
 *
 * 注意：
 * - index_indicator_daily 的市值单位为元。
 * - index_k_daily.turnover 的注释为千元，如果后端保持千元单位，可在入参前或后端统一换算。
 */
export function formatAmount(value?: number | null, suffix = ''): string {
    if (value === undefined || value === null || Number.isNaN(Number(value))) return '-'

    const numberValue = Number(value)
    const abs = Math.abs(numberValue)
    const sign = numberValue < 0 ? '-' : ''

    if (abs >= 1_0000_0000_0000) return `${sign}${formatNumber(abs / 1_0000_0000_0000, 2)}万亿${suffix}`
    if (abs >= 1_0000_0000) return `${sign}${formatNumber(abs / 1_0000_0000, 2)}亿${suffix}`
    if (abs >= 1_0000) return `${sign}${formatNumber(abs / 1_0000, 2)}万${suffix}`

    return `${sign}${formatNumber(abs, 2)}${suffix}`
}

export function signedClass(value?: number | null): string {
    if (value === undefined || value === null || Number.isNaN(Number(value))) return 'is-flat'
    if (value > 0) return 'is-up'
    if (value < 0) return 'is-down'
    return 'is-flat'
}

export function marketStatusText(status?: IndexMarketStatus | string): string {
    const map: Record<string, string> = {
        PRE_MARKET: '盘前',
        TRADING: '交易中',
        MIDDAY_BREAK: '午间休市',
        CLOSED: '已收盘',
        SUSPENDED: '暂停',
        UNKNOWN: '未知'
    }
    return status ? map[String(status)] || String(status) : '-'
}

export function indexMarketText(market?: string): string {
    const map: Record<string, string> = {
        MSCI: 'MSCI 指数',
        CSI: '中证指数',
        SSE: '上交所指数',
        SZSE: '深交所指数',
        CICC: '中金指数',
        SW: '申万指数',
        OTH: '其他指数'
    }
    return market ? map[market] || market : '-'
}

export function valuationStatusText(status?: IndexValuationStatus | string): string {
    const map: Record<string, string> = {
        UNDERVALUED: '偏低估',
        FAIR: '合理',
        OVERVALUED: '偏高估',
        UNKNOWN: '未知'
    }
    return status ? map[String(status)] || String(status) : '-'
}

export function overallViewText(view?: IndexOverallView | string): string {
    const map: Record<string, string> = {
        STRONGLY_BULLISH: '强烈偏多',
        BULLISH: '偏多',
        NEUTRAL: '中性',
        BEARISH: '偏空',
        STRONGLY_BEARISH: '强烈偏空'
    }
    return view ? map[String(view)] || String(view) : '-'
}

export function riskLevelText(level?: IndexRiskLevel | string): string {
    const map: Record<string, string> = {
        LOW: '低',
        MEDIUM: '中',
        HIGH: '高',
        EXTREME: '极高'
    }
    return level ? map[String(level)] || String(level) : '-'
}

export function statusTagType(
    status?: MetricStatus | IndexRiskLevel | IndexOverallView | IndexValuationStatus | string
): '' | 'success' | 'warning' | 'danger' | 'info' | 'primary' {
    const value = String(status || '')
    if (['GOOD', 'LOW', 'BULLISH', 'STRONGLY_BULLISH', 'UNDERVALUED'].includes(value)) return 'success'
    if (['NORMAL', 'MEDIUM', 'NEUTRAL', 'FAIR'].includes(value)) return 'warning'
    if (['WARNING', 'HIGH', 'EXTREME', 'BEARISH', 'STRONGLY_BEARISH', 'OVERVALUED'].includes(value)) return 'danger'
    if (['DANGER'].includes(value)) return 'danger'
    return 'info'
}
