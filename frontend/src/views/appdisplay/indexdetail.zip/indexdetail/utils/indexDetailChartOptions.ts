import type { EChartsOption } from 'echarts'
import type { ChartGroup, IndexConstituentInfo, OHLCData, WeightItem } from '/@/types/indexdetail/indexDetailCenter'
import { formatAmount, formatPercent } from './indexDetailFormat'

function isOhlcData(value: unknown): value is OHLCData {
    return Boolean(value && typeof value === 'object' && 'tradeDate' in value && 'open' in value && 'close' in value)
}

export function getOhlcRows(chart?: ChartGroup): OHLCData[] {
    if (!chart?.series?.length) return []
    return chart.series[0].data.filter(isOhlcData)
}

export function buildCandlestickOption(chart: ChartGroup): EChartsOption {
    const rows = getOhlcRows(chart)
    const dates = rows.map(item => item.tradeDate)
    const kData = rows.map(item => [item.open, item.close, item.low, item.high])
    const volumeData = rows.map((item, index) => ({
        value: item.volume || 0,
        itemStyle: {
            color: item.close >= item.open ? '#ef5350' : '#26a69a'
        },
        dataIndex: index
    }))

    return {
        animation: false,
        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'cross' },
            formatter(params: any) {
                const list = Array.isArray(params) ? params : [params]
                const kItem = list.find((item: any) => item.seriesType === 'candlestick')
                const volumeItem = list.find((item: any) => item.seriesName === '成交量')
                if (!kItem) return ''

                const row = rows[kItem.dataIndex]
                return [
                    row.tradeDate,
                    `开盘：${row.open}`,
                    `收盘：${row.close}`,
                    `最低：${row.low}`,
                    `最高：${row.high}`,
                    `成交量：${formatAmount(row.volume)}`,
                    `成交额：${formatAmount(row.turnover)}`,
                    volumeItem ? `量柱：${formatAmount(volumeItem.value)}` : ''
                ].filter(Boolean).join('<br/>')
            }
        },
        legend: { top: 0, data: ['K线', '成交量'] },
        grid: [
            { left: 56, right: 24, top: 40, height: 230 },
            { left: 56, right: 24, top: 305, height: 80 }
        ],
        xAxis: [
            {
                type: 'category',
                data: dates,
                boundaryGap: true,
                axisLine: { lineStyle: { color: '#909399' } },
                axisLabel: { color: '#606266' },
                min: 'dataMin',
                max: 'dataMax'
            },
            {
                type: 'category',
                gridIndex: 1,
                data: dates,
                boundaryGap: true,
                axisLine: { lineStyle: { color: '#909399' } },
                axisLabel: { color: '#606266' },
                min: 'dataMin',
                max: 'dataMax'
            }
        ],
        yAxis: [
            {
                scale: true,
                axisLine: { lineStyle: { color: '#909399' } },
                axisLabel: { color: '#606266' },
                splitLine: { lineStyle: { color: '#ebeef5' } }
            },
            {
                scale: true,
                gridIndex: 1,
                axisLabel: {
                    color: '#606266',
                    formatter(value: number) {
                        return formatAmount(value)
                    }
                },
                splitLine: { lineStyle: { color: '#ebeef5' } }
            }
        ],
        dataZoom: [
            {
                type: 'inside',
                xAxisIndex: [0, 1],
                start: Math.max(0, 100 - Math.min(100, Math.round(60 / Math.max(rows.length, 1) * 100))),
                end: 100
            },
            {
                show: true,
                xAxisIndex: [0, 1],
                type: 'slider',
                bottom: 0,
                height: 22,
                start: Math.max(0, 100 - Math.min(100, Math.round(60 / Math.max(rows.length, 1) * 100))),
                end: 100
            }
        ],
        series: [
            {
                name: 'K线',
                type: 'candlestick',
                data: kData,
                itemStyle: {
                    color: '#ef5350',
                    color0: '#26a69a',
                    borderColor: '#ef5350',
                    borderColor0: '#26a69a'
                }
            },
            {
                name: '成交量',
                type: 'bar',
                xAxisIndex: 1,
                yAxisIndex: 1,
                data: volumeData
            }
        ]
    }
}

export function buildLineOption(chart: ChartGroup, percent = false): EChartsOption {
    const xAxis = chart.xAxis || chart.series[0]?.data.map((_, index) => String(index + 1)) || []

    return {
        tooltip: {
            trigger: 'axis',
            valueFormatter(value: any) {
                const num = Number(value)
                return percent ? formatPercent(num) : formatAmount(num)
            }
        },
        legend: { top: 0 },
        grid: { left: 56, right: 24, top: 42, bottom: 46 },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: xAxis,
            axisLabel: { color: '#606266' },
            axisLine: { lineStyle: { color: '#909399' } }
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                color: '#606266',
                formatter(value: number) {
                    return percent ? `${value}%` : formatAmount(value)
                }
            },
            splitLine: { lineStyle: { color: '#ebeef5' } }
        },
        dataZoom: [{ type: 'inside' }, { type: 'slider', bottom: 8, height: 22 }],
        series: chart.series.map(item => ({
            name: item.name,
            type: 'line',
            smooth: true,
            showSymbol: false,
            data: item.data
        }))
    }
}

export function buildBarOption(chart: ChartGroup, signed = false): EChartsOption {
    const xAxis = chart.xAxis || chart.series[0]?.data.map((_, index) => String(index + 1)) || []

    return {
        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'shadow' },
            valueFormatter(value: any) {
                return formatAmount(Number(value))
            }
        },
        legend: { top: 0 },
        grid: { left: 64, right: 24, top: 42, bottom: 46 },
        xAxis: {
            type: 'category',
            data: xAxis,
            axisLabel: { color: '#606266' },
            axisLine: { lineStyle: { color: '#909399' } }
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                color: '#606266',
                formatter(value: number) {
                    return formatAmount(value)
                }
            },
            splitLine: { lineStyle: { color: '#ebeef5' } }
        },
        dataZoom: [{ type: 'inside' }, { type: 'slider', bottom: 8, height: 22 }],
        series: chart.series.map(item => ({
            name: item.name,
            type: 'bar',
            data: signed
                ? item.data.map(value => ({
                    value,
                    itemStyle: { color: Number(value) >= 0 ? '#ef5350' : '#26a69a' }
                }))
                : item.data
        }))
    }
}

export function buildPieOption(title: string, data: WeightItem[]): EChartsOption {
    return {
        tooltip: {
            trigger: 'item',
            formatter(params: any) {
                return `${params.name}<br/>权重：${formatPercent(params.value)}`
            }
        },
        legend: { orient: 'vertical', right: 8, top: 'middle' },
        series: [
            {
                name: title,
                type: 'pie',
                radius: ['42%', '68%'],
                center: ['38%', '50%'],
                avoidLabelOverlap: true,
                label: { formatter: '{b}\n{d}%' },
                data: data.map(item => ({ name: item.name, value: item.weight }))
            }
        ]
    }
}

export function buildBreadthPieOption(constituents?: IndexConstituentInfo): EChartsOption {
    return {
        tooltip: { trigger: 'item' },
        legend: { bottom: 0 },
        series: [
            {
                name: '成分涨跌分布',
                type: 'pie',
                radius: ['40%', '68%'],
                data: [
                    { name: '上涨', value: constituents?.upCount || 0, itemStyle: { color: '#ef5350' } },
                    { name: '下跌', value: constituents?.downCount || 0, itemStyle: { color: '#26a69a' } },
                    { name: '平盘', value: constituents?.flatCount || 0, itemStyle: { color: '#909399' } }
                ]
            }
        ]
    }
}
